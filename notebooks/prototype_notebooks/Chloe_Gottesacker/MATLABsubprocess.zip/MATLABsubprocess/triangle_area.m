%% CALCULATE AREA OF A TRIANGLE
%  Simple script to test running MATLAB from Python

% Calculate area:
b = 5;
h = 3;
a = 0.5*(b.* h);   %area

save('a.txt','a', '-ASCII')

